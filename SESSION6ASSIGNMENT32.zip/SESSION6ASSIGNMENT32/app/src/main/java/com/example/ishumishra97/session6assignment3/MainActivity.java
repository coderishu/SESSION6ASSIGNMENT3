package com.example.ishumishra97.session6assignment3;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=(TextView)findViewById(R.id.textView);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.gla, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.red:
                tv.setTextColor(Color.parseColor("#FF0000"));
                return true;
            case R.id.blue:
                tv.setTextColor(Color.parseColor("#0000FF"));
                return true;
            case R.id.green:
                tv.setTextColor(Color.parseColor("#00FF00"));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
